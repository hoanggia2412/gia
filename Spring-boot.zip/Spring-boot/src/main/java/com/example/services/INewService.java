package com.example.services;



import com.example.dto.NewDTO;

public interface INewService {
	
	NewDTO save(NewDTO newDTO);
//	NewDTO update(NewDTO newDTO);
	
}
