package com.example.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.converter.NewConverter;
import com.example.dto.NewDTO;
import com.example.entity.CategoryEntity;
import com.example.entity.NewEntity;
import com.example.repository.CategoryRepository;
import com.example.repository.NewRepository;
import com.example.services.INewService;

@Service
public class NewService implements INewService{
	@Autowired
	private NewRepository newRepository;
	
	@Autowired
	private CategoryRepository categoryRepository;

	@Autowired
	private NewConverter newConverter;
	
	@Override
	public NewDTO save(NewDTO newDTO) {
		
		NewEntity newEntity = newConverter.toEntity(newDTO);
		if(newDTO.getId()!=null) {
			NewEntity oldNew = newRepository.getOne(newDTO.getId());
			newEntity = newConverter.toEntity(newDTO, oldNew);
		}else {
			newEntity = newConverter.toEntity(newDTO);
		}
		
	CategoryEntity categoryEntity = categoryRepository.findOneByCode(newDTO.getCategoryCode());
	
	newEntity.setCategory(categoryEntity);
	newEntity = newRepository.save(newEntity);
	return newConverter.toDTO(newEntity);
	}
//	@Override
//	public NewDTO update(NewDTO newDTO) {
//		NewEntity oldNew = newRepository.getOne(newDTO.getId());
//		NewEntity newEntity = newConverter.toEntity(newDTO, oldNew);
//		CategoryEntity categoryEntity = categoryRepository.findOneByCode(newDTO.getCategoryCode());
//		newEntity.setCategory(categoryEntity);
//		newEntity = newRepository.save(newEntity);
//		return newConverter.toDTO(newEntity);
//	}
}
